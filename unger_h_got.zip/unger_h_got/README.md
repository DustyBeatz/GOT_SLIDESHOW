# GOT Video App
JS-based house explainer with video synopsis for each

Basic HTML 5 app with ES6, CSS animation and video

Homework requirements:
- add another sigil, and the house's banner
- add more controls to the video player
- change the order of operation  

from:
- video, animate, add info

to:
- animate and add info, check for annimation to finish, then load lightbox/video
